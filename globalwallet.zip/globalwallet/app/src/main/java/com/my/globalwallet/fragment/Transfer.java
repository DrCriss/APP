package com.my.globalwallet.fragment;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.my.globalwallet.R;
import com.my.globalwallet.RecordActivity;

import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class Transfer extends Fragment {

    private EditText etHKD, etCNY;
    private Button btnConvertToCNY, btnConvertToHKD,btnBack;
    private static double EXCHANGE_RATE = 0.91; // 默认汇率
    //private static final String API_URL = "https://www.floatrates.com/daily/cny.json/";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_transfer, container, false);

        // 绑定控件
        etHKD = view.findViewById(R.id.et_hkd);
        etCNY = view.findViewById(R.id.et_cny);
        btnConvertToCNY = view.findViewById(R.id.btn_convert_to_cny);
        btnConvertToHKD = view.findViewById(R.id.btn_convert_to_hkd);
        btnBack = view.findViewById(R.id.btn_back);

        // 按钮点击事件
        btnConvertToCNY.setOnClickListener(v -> convertToCNY());
        btnConvertToHKD.setOnClickListener(v -> convertToHKD());
        btnBack.setOnClickListener(v-> getBacktoRecord());

        // 加载最新汇率
        loadCachedExchangeRate();
        fetchExchangeRate();

        return view;
    }
    //去记账
    private  void getBacktoRecord(){
        String cnyStr = etCNY.getText().toString();
        if (!TextUtils.isEmpty(cnyStr)) {
            //double cny = Double.parseDouble(cnyStr);
            RecordActivity activity = (RecordActivity) requireActivity();
            activity.passDataToOutcome(cnyStr); // 将数据传递到 OutCome Fragment
            Toast.makeText(getActivity(),"已跳转并传递金额"+cnyStr,Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getActivity(), "记账前请输入港币金额,转换为人民币后才可记账", Toast.LENGTH_SHORT).show();
        }
    }


    // 港币转人民币
    private void convertToCNY() {
        String hkdStr = etHKD.getText().toString();
        if (!TextUtils.isEmpty(hkdStr)) {
            double hkd = Double.parseDouble(hkdStr);
            double cny = hkd * EXCHANGE_RATE;
            etCNY.setText(String.format("%.2f", cny));
        } else {
            Toast.makeText(getActivity(), "请输入港币金额", Toast.LENGTH_SHORT).show();
        }
    }

    // 人民币转港币
    private void convertToHKD() {
        String cnyStr = etCNY.getText().toString();
        if (!TextUtils.isEmpty(cnyStr)) {
            double cny = Double.parseDouble(cnyStr);
            double hkd = cny / EXCHANGE_RATE;
            etHKD.setText(String.format("%.2f", hkd));
        } else {
            Toast.makeText(getActivity(), "请输入人民币金额", Toast.LENGTH_SHORT).show();
        }
    }

    // 动态获取汇率
    private void fetchExchangeRate() {
        OkHttpClient client = new OkHttpClient();

        // 使用新的汇率 API URL
        String API_URL = "https://www.floatrates.com/daily/hkd.json";

        Request request = new Request.Builder()
                .url(API_URL)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                // 请求失败，显示错误信息
                getActivity().runOnUiThread(() -> {
                    Toast.makeText(getActivity(), "无法获取汇率，请检查网络连接或稍后重试", Toast.LENGTH_LONG).show();
                });
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseBody = response.body().string();
                    try {
                        // 解析 JSON 数据
                        JSONObject jsonObject = new JSONObject(responseBody);
                        JSONObject hkdObject = jsonObject.getJSONObject("cny");
                        double rate = hkdObject.getDouble("rate");

                        // 更新汇率
                        EXCHANGE_RATE = rate;

                        // 缓存汇率
                        cacheExchangeRate(rate);

                        // 更新 UI
                        getActivity().runOnUiThread(() -> {
                            Toast.makeText(getActivity(), "最新汇率已更新: 1 HKD = " + EXCHANGE_RATE + " CNY", Toast.LENGTH_SHORT).show();
                        });
                    } catch (Exception e) {
                        e.printStackTrace();
                        getActivity().runOnUiThread(() -> {
                            Toast.makeText(getActivity(), "解析汇率数据失败，请稍后重试", Toast.LENGTH_LONG).show();
                        });
                    }
                }
                else {
                    // 如果请求失败
                    getActivity().runOnUiThread(() -> {
                        Toast.makeText(getActivity(), "获取汇率失败，请稍后重试", Toast.LENGTH_LONG).show();
                    });
                }
            }
        });
    }


    // 缓存汇率
    private void cacheExchangeRate(double rate) {
        SharedPreferences prefs = getActivity().getSharedPreferences("exchange_rate", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putFloat("last_rate", (float) rate);
        editor.apply();
    }

    // 加载缓存的汇率
    private void loadCachedExchangeRate() {
        SharedPreferences prefs = getActivity().getSharedPreferences("exchange_rate", Context.MODE_PRIVATE);
        float cachedRate = prefs.getFloat("last_rate", (float) EXCHANGE_RATE);
        EXCHANGE_RATE = cachedRate;
    }



}
