package com.my.globalwallet;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.view.View;

import com.google.android.material.tabs.TabLayout;
import com.my.globalwallet.fragment.Transfer;
import com.my.globalwallet.adapter.RecordAdapter;
import com.my.globalwallet.fragment.InCome;
import com.my.globalwallet.fragment.OutCome;

import java.util.ArrayList;
import java.util.List;

public class RecordActivity extends AppCompatActivity {
    TabLayout tabLayout;
    ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record);
        
        //1.查找控件
        tabLayout = findViewById(R.id.record_tabs);
        viewPager = findViewById(R.id.record_vp);
        
        //2.设置ViewPaper加载页面
        initPager();
    }

    private void initPager() {
        //初始化ViewPaper页面的集合
        List<Fragment> fragmentList = new ArrayList<>();
        //创建收入和支出页面，放置在Fragment中
        OutCome outFrag = new OutCome(); //支出
        InCome inFrag = new InCome(); //收入
        Transfer transFrag = new Transfer();
        fragmentList.add(outFrag);
        fragmentList.add(inFrag);
        fragmentList.add(transFrag);
        
        //创建适配器
        RecordAdapter paperAdapter = new RecordAdapter(getSupportFragmentManager(),fragmentList);
        
        //设置适配器对象
        viewPager.setAdapter(paperAdapter);
        
        //将TabLayout和ViewPaper关联
        tabLayout.setupWithViewPager(viewPager);
    }

    public void passDataToOutcome(String data) {
        // 获取适配器
        RecordAdapter adapter = (RecordAdapter) viewPager.getAdapter();
        if (adapter != null) {
            // 根据位置获取特定的 Fragment
            OutCome outComeFragment = (OutCome) adapter.getFragment(0); // 0 表示 "支出" 页的索引
            if (outComeFragment != null) {
                // 调用 OutCome Fragment 中的方法
                //outComeFragment.updateData(data);
                //切换到Outcome页
                viewPager.setCurrentItem(0,true);
                viewPager.postDelayed(() -> outComeFragment.updateData(data), 100);
            }

        }
    }


    /*点击事件*/
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.record_iv_back:
                finish();
                break;
        }
    }
}