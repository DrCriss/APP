package com.my.globalwallet.fragment;

import android.widget.Toast;

import com.my.globalwallet.database.DataBaseManager;
import com.my.globalwallet.R;
import com.my.globalwallet.database.Type;

import java.util.List;

//Outcome 为 BaseFregment 的子类
public class OutCome extends BaseFragment {

    //重写
    @Override
    public void loadData() {
        super.loadData();
        //获取数据库中的数据源
        List<Type> outList = DataBaseManager.gettypelist(0);
        typeList.addAll(outList);
        adapter.notifyDataSetChanged();
        typeTv.setText("餐饮(主食)");
        typeIv.setImageResource(R.mipmap.ic_food1_red);
    }

    @Override
    public void saveAccountToDatabase() {
        accountSeed.setKind(0);
        DataBaseManager.insertToAtb(accountSeed);
    }

    public void updateData(String data) {
        if (moneyEt != null && data != null) {
            moneyEt.setText(data); // 更新金额输入框
            Toast.makeText(getActivity(), "收到的数据: " + data, Toast.LENGTH_SHORT).show();
        }
    }
}
